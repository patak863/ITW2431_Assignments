# Name: Mike Patak
# ITW 2431
# Project 9 Prob. 1
# File name: ITW2431_P9_P1_mpatak.py
# MODIFIED: xxxxxxx2/24/22
# PURPOSE:  The program will create a tuple using course and instructor
#           data included in the program and print out the 'old tuple'.
#           The program will then update one of the course/instructor
#           tuple with a new course/instructor tuple and print out the
#           'updated tuple'.
# ASSUMPTIONS:  The data used by the program is hard coded in the program.
###########################################################################

